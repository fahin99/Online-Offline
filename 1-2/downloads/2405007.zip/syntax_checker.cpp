#include <stack>
#include <string>
using namespace std;

/**
 * Helper function to check if an opening bracket matches a closing bracket
 * @param opening: The opening bracket character
 * @param closing: The closing bracket character
 * @return true if they form a matching pair, false otherwise
 */
bool isMatchingPair(char opening, char closing) {
    // TODO: Implement this helper function
    // Check if opening and closing brackets match
    // Valid pairs: (), [], {}
    if(opening == '(' && closing == ')') return true;
    else if(opening == '[' && closing == ']') return true;
    else if(opening == '{' && closing == '}') return true;
    return false;
}

/**
 * Checks if brackets in an arithmetic expression are properly matched
 * @param expression: A string containing an arithmetic expression
 * @return true if all brackets are properly matched and balanced, false otherwise
 */
bool isValidExpression(const string& expression) {
    // TODO: Implement the syntax checker using std::stack
    stack<char> bracket;
    for(char c:expression){
        if(c=='(' or c=='[' or c=='{'){
            bracket.push(c);
        }
        else if(c==')' or c==']' or c=='}'){
            if(bracket.empty() or !isMatchingPair(bracket.top(),c)){
                return false;
            }
            bracket.pop();
        }
    }
    return bracket.empty();
}
