#include<bits/stdc++.h>
using namespace std;

bool bfs(int s, int t, vector<int>&parent, vector<vector<int>>&cap, vector<vector<int>>&adj){
    vector<bool> vis(parent.size(), 0);
    for(int i=0;i<parent.size();i++) parent[i]=-1;
    queue<int> q;
    q.push(s);
    vis[s]=true;
    parent[s]=-1;
    while(!q.empty()){
        int u=q.front();
        q.pop();
        for(auto v: adj[u]){
            if(!vis[v] and cap[u][v]>0){
                parent[v]=u;
                vis[v]=true;
                if(v==t) return true;
                q.push(v);
            }
        }
    }
    return false;
}

int max_flow(int s, int t, vector<vector<int>>&cap, vector<vector<int>>&adj){
    vector<int>parent(adj.size(), -1);
    int flow=0;
    while(bfs(s, t, parent, cap, adj)){
        int path=INT_MAX, v=t;
        while(v!=s){
            int u=parent[v];
            path=min(path, cap[u][v]);
            v=u;
        }
        v=t;
        while(v!=s){
            int u=parent[v];
            cap[u][v]-=path;
            cap[v][u]+=path;
            v=u;
        }
        flow+=path;
    }
    return flow;
}

struct flight{
    int strt, end;
    string id, src, dest;
};

int hr_to_min(string s){
    int colon=s.find(':');
    return stoi(s.substr(0,colon))*60 + stoi(s.substr(colon+1));
}

int main(){
    int f;
    cin>>f;
    vector<flight> flights(f);
    vector<vector<int>> adj(2*f+2);
    vector<vector<int>> cap(2*f+2, vector<int>(2*f+2));

    for(int i=0;i<f;i++){
        cin>>flights[i].id>>flights[i].src>>flights[i].dest;
        string strt, end;
        cin>>strt>>end;
        flights[i].strt=hr_to_min(strt);
        flights[i].end=hr_to_min(end);
    }
    int s=0, t=2*f+1;
    for(int i=0;i<f;i++){
        //left part
        adj[s].push_back(i+1);
        adj[i+1].push_back(s);
        cap[s][i+1]=1;
        //right part
        adj[f+1+i].push_back(t);
        adj[t].push_back(f+i+1);
        cap[f+i+1][t]=1;

        for(int j=0;j<f;j++){
            if(i==j) continue;
            if(flights[i].dest==flights[j].src and (flights[i].end+180<=flights[j].strt)){
                adj[1+i].push_back(f+1+j);
                adj[f+1+j].push_back(1+i);
                cap[1+i][f+1+j]=1;
            }
        }
    }
    int match=max_flow(s,t,cap,adj);
    cout<<"Number of Aircrafts: "<<f-match<<endl;
    vector<int> nxt(f,-1), prev(f,-1);
    for(int i=0;i<f;i++){
        for(int j=0;j<f;j++){
            if(cap[f+1+j][1+i]>0){
                nxt[i]=j;
                prev[j]=i;
            }
        }
    }
    int cnt=1;
    for(int i=0;i<f;i++){
        if(prev[i]==-1){
            cout<<"Aircraft "<<cnt++<<": ";
            int cur=i;
            while(cur!=-1){
                cout<<flights[cur].id;
                cur=nxt[cur];
                if(cur!=-1) cout<<" -> ";
            }
            cout<<endl;
        }
    }
    return 0;
}
